﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TaskSchedular.Migrations
{
    public partial class SampleDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
